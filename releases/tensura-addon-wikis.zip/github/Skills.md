# Skills

> **Discontinued archive:** Tensura Myths ended at 0.36.1. No further updates are planned.

[All wikis](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Home) · [Tensura Myths](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Tensura-Myths)

Equip active arts and toggle passives in Tensura’s skill menu. Toggle upkeep is paid while enabled; unfunded passives turn off.

| Tier | Obtaining | Pages |
| --- | --- | --- |
| Unique | Reincarnation rolls | [Eight starting skills](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Unique-Skills); [Chained](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Chained) is race-exclusive |
| Ultimate | Two mastered Uniques; 2M total EP | [Recipes](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Skill-Synthesis) |
| Godly | Mastered combination Ultimate; true awakening; 12M total EP | [Aion, Thoth, Lugh](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Godly) |
| Extra | Race evolution | [Aura recovery](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Aura-Regeneration) |
| Battlewill | Learning/evolution | [Schema, Air Walk, Instant Transmission](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Battlewills) |

Unless a page says otherwise, playable attack values scale from **1× to 1.5×** with mastery. EP does not directly multiply skill damage. Listed damage is before defenses and other modifiers.

[All abilities and damage types](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Abilities).
