# Tempered Vessel

> **Discontinued archive:** Tensura Myths ended at 0.36.1. No further updates are planned.

[All wikis](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Home) · [Tensura Myths](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Tensura-Myths)

**Tempered Vessel** is evolution 1 of four of the **Heavenly Restriction** lineage. A human-looking martial body exchanges magical growth for exceptional physical and aura potential through **Chained**, the Unique Skill inherited from Fettered Human.

| Race data | Value |
| --- | --- |
| Ancestry | Human |
| Stage | 1 / 4 evolutions |
| Retained Unique | [Chained](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Chained); granted only by Fettered Human |
| HP racial bonus | +100 |
| SHP racial bonus | +400 |
| Attack bonus | +4 |
| Movement bonus | +7.5% of base movement |
| Knockback resistance bonus | +0.15 |
| Previous evolution | [Fettered Human](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Fettered-Human) |
| Next evolution | [Unshackled](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Unshackled) |

## Evolution

[Heavenly Restriction progression](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Fettered-Human). Racial bonuses replace earlier stages; they do not stack.
