# Nereid Oracle

[All wikis](https://github.com/Bithio999/MC/wiki/Home) · [Tensura Myths](https://github.com/Bithio999/MC/wiki/Tensura-Myths)

**Nereid Oracle** is the unique Convergent race formed from **Merfolk** and **Elf** ancestry. Merfolk vitality and Elf spirit form a single stable lineage.

![Race icon](https://github.com/Bithio999/MC/raw/refs/heads/main/wiki/assets/race/convergence/elf_merfolk.png)

| Race data | Value |
| --- | --- |
| Ancestries | Merfolk + Elf |
| Alignment | Chaos |
| Aura gain weight | 4.125 |
| Magicule gain weight | 1.875 |
| Growth at a baseline of 3, including +10% | 13.6125 aura / 6.1875 magicules |

## Obtaining

Finish both ancestral evolution paths, become a True Hero or True Demon Lord, and meet the fixed EP gate shown in the **Convergent Awakening** tab (at least 10M EP). Awakening grants a one-time +25% to both base energy pools and retains learned skills and the +10% EP gain bonus.

## Racial ability

**Concordance Pulse — no damage.** Heal 50% maximum HP and SHP, without a fixed amount cap, and push nearby enemies. Cost: **1,500 aura**. Cooldown: **30 seconds**. Healing stops at your current maximums.

Traits combine both final ancestries. [Awakening details and shared traits](https://github.com/Bithio999/MC/wiki/Convergent-Awakening).
