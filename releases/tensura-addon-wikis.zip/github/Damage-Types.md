# Damage types

> **Discontinued archive:** Tensura Myths ended at 0.36.1. No further updates are planned.

[All wikis](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Home) · [Tensura Myths](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Tensura-Myths)

Ability pages identify the attack’s damage type. Visual color alone does not determine damage.

| Damage family | Used for |
| --- | --- |
| Physical / Aura Slash | Weapon attacks, Severance Rush, Counter and physical techniques |
| Fire, Water/Ice, Earth, Wind, Lightning, Light, Darkness, Space, Gravity | Elemental attacks; each uses its own native defenses |
| Generic magic | Non-elemental reconstructed magic |
| None | Healing, movement, resource conversion and buffs |
| Reflected / copied | Retains the type described by the source or bank entry |

Water and Ice share an elemental family for Thoth’s cycle, which uses **Water** once. Burn/Frost and other status damage is separate from a move’s opening hit. Shields, armor, resistances and skill effects can reduce the result.

[Ability directory](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Abilities) · [Combat rules](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Mechanics).
