# Air Walk

> **Discontinued archive:** Tensura Myths ended at 0.36.1. No further updates are planned.

[All wikis](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Home) · [Tensura Myths](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Tensura-Myths)

A Battlewill evolution of Air Float / Air Flight.

![Air Walk icon](https://github.com/Bithio999/TensuraAdditionalAdditions/raw/refs/heads/main/wiki/assets/battlewill/air_sovereignty.png)

| Skill data | Value |
| --- | --- |
| Tier | Battlewill |
| Damage type | None |


## Learn

Master your permanent Air Float, then complete the new learning entry in the Battlewill menu.


## Use

Press to enable free flight using aura. Press again to stop; stopping is free even with empty aura.

Cost: 30 aura to activate and 30 aura per second actually flying. Mastery halves both to 15. No magicule cost or cooldown.


## Related

[Instant Transmission](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Instant-Transmission) · [Schema](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Schema)
