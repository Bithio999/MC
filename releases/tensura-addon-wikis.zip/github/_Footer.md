[All wikis](https://github.com/Bithio999/MC/wiki) · [Tensura Myths 0.36.1](https://github.com/Bithio999/MC/wiki/Tensura-Myths) · [TensuraAdditionalAdditions 1.6.1](https://github.com/Bithio999/MC/wiki/TensuraAdditionalAdditions)

Unofficial addon reference · [Source](https://github.com/Bithio999/MC)
