# Abyssal Chimera

> **Discontinued archive:** Tensura Myths ended at 0.36.1. No further updates are planned.

[All wikis](https://github.com/Bithio999/MC/wiki/Home) · [Tensura Myths](https://github.com/Bithio999/MC/wiki/Tensura-Myths)

**Abyssal Chimera** is the unique Convergent race formed from **Beastfolk** and **Daemon** ancestry. Beastfolk vitality and Daemon spirit form a single stable lineage.

![Race icon](https://github.com/Bithio999/MC/raw/refs/heads/main/wiki/assets/race/convergence/beastfolk_daemon.png)

| Race data | Value |
| --- | --- |
| Ancestries | Beastfolk + Daemon |
| Alignment | Chaos |
| Aura gain weight | 2.805 |
| Magicule gain weight | 3.195 |
| Growth at a baseline of 3, including +10% | 9.2565 aura / 10.5435 magicules |

## Obtaining

Finish both ancestral evolution paths, become a True Hero or True Demon Lord, and meet the fixed EP gate shown in the **Convergent Awakening** tab (at least 10M EP). Awakening grants a one-time +25% to both base energy pools and retains learned skills and the +10% EP gain bonus.

## Racial ability

**Concordance Pulse — no damage.** Heal 50% maximum HP and SHP, without a fixed amount cap, and push nearby enemies. Cost: **1,500 aura**. Cooldown: **30 seconds**. Healing stops at your current maximums.

Traits combine both final ancestries. [Awakening details and shared traits](https://github.com/Bithio999/MC/wiki/Convergent-Awakening).
