# Origin Sovereign

> **Discontinued archive:** Tensura Myths ended at 0.36.1. No further updates are planned.

[All wikis](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Home) · [Tensura Myths](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Tensura-Myths)

**Origin Sovereign** is Eschaton's boss-exclusive divine, spiritual lineage. It has no player evolution path, secondary-race selection or reincarnation roll.

| Race data | Value |
| --- | --- |
| Owner | [Eschaton, the Last Myth](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Eschaton) |
| Classification | Divine; spiritual; no blood; creative flight |
| Base aura / magicules | 500,000,000 / 500,000,000 |
| Total base EP | 1,000,000,000 |
| Intrinsic skills | [Demiurge](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Demiurge), [Aion](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Aion), [Thoth](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Thoth) |
| Evolution / acquisition | Encounter-exclusive; no player route |

This lineage belongs to its [Myth boss](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Bosses); it is not a starting race choice.
