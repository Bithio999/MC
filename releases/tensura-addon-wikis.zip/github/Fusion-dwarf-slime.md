# Quicksilver Artificer

> **Discontinued archive:** Tensura Myths ended at 0.36.1. No further updates are planned.

[All wikis](https://github.com/Bithio999/MC/wiki/Home) · [Tensura Myths](https://github.com/Bithio999/MC/wiki/Tensura-Myths)

**Quicksilver Artificer** is the unique Convergent race formed from **Dwarf** and **Slime** ancestry. Dwarf vitality and Slime spirit form a single stable lineage.

![Race icon](https://github.com/Bithio999/MC/raw/refs/heads/main/wiki/assets/race/convergence/dwarf_slime.png)

| Race data | Value |
| --- | --- |
| Ancestries | Dwarf + Slime |
| Alignment | Chaos |
| Aura gain weight | 3.215 |
| Magicule gain weight | 2.785 |
| Growth at a baseline of 3, including +10% | 10.6095 aura / 9.1905 magicules |

## Obtaining

Finish both ancestral evolution paths, become a True Hero or True Demon Lord, and meet the fixed EP gate shown in the **Convergent Awakening** tab (at least 10M EP). Awakening grants a one-time +25% to both base energy pools and retains learned skills and the +10% EP gain bonus.

## Racial ability

**Concordance Pulse — no damage.** Heal 50% maximum HP and SHP, without a fixed amount cap, and push nearby enemies. Cost: **1,500 aura**. Cooldown: **30 seconds**. Healing stops at your current maximums.

Traits combine both final ancestries. [Awakening details and shared traits](https://github.com/Bithio999/MC/wiki/Convergent-Awakening).
