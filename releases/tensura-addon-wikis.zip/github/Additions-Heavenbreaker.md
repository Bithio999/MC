# Heavenbreaker

[All wikis](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Home) · [TensuraAdditionalAdditions](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/TensuraAdditionalAdditions)

**Heavenbreaker** is evolution 4 of four of the **Heavenly Restriction** lineage. A human-looking martial body exchanges magical growth for exceptional physical and aura potential through **Chained**, the Unique Skill inherited from Fettered Human.

| Race data | Value |
| --- | --- |
| Ancestry | Human |
| Stage | 4 / 4 evolutions |
| Recovery Extra | [Sovereign Rebirth](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Additions-Sovereign-Rebirth) |
| Retained Unique | [Chained](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Additions-Chained); granted only by Fettered Human |
| HP racial bonus | +1,000 |
| SHP racial bonus | +6,600 |
| Attack bonus | +16 |
| Movement bonus | +30% of base movement |
| Knockback resistance bonus | +0.6 |
| Previous evolution | [Heavenly Restricted](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Additions-Heavenly-Restricted) |
| Next evolution | Final stage |

## Evolution

[Heavenly Restriction progression](https://github.com/Bithio999/TensuraAdditionalAdditions/wiki/Additions-Fettered-Human). Racial bonuses replace earlier stages; they do not stack.
