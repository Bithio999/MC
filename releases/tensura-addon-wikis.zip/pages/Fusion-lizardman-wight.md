# Ossuary Dragon

> **Discontinued archive:** Tensura Myths ended at 0.36.1. No further updates are planned.

[All wikis](../README.md) · [Tensura Myths](Tensura-Myths.md)

**Ossuary Dragon** is the unique Convergent race formed from **Lizardman** and **Wight** ancestry. Lizardman vitality and Wight spirit form a single stable lineage.

![Race icon](../assets/race/convergence/lizardman_wight.png)

| Race data | Value |
| --- | --- |
| Ancestries | Lizardman + Wight |
| Alignment | Chaos |
| Aura gain weight | 3.115 |
| Magicule gain weight | 2.885 |
| Growth at a baseline of 3, including +10% | 10.2795 aura / 9.5205 magicules |

## Obtaining

Finish both ancestral evolution paths, become a True Hero or True Demon Lord, and meet the fixed EP gate shown in the **Convergent Awakening** tab (at least 10M EP). Awakening grants a one-time +25% to both base energy pools and retains learned skills and the +10% EP gain bonus.

## Racial ability

**Concordance Pulse — no damage.** Heal 50% maximum HP and SHP, without a fixed amount cap, and push nearby enemies. Cost: **1,500 aura**. Cooldown: **30 seconds**. Healing stops at your current maximums.

Traits combine both final ancestries. [Awakening details and shared traits](Convergent-Awakening.md).
