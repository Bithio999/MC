# Mercurial Ouroboros

[All wikis](../README.md) · [Tensura Myths](Tensura-Myths.md)

**Mercurial Ouroboros** is the unique Convergent race formed from **Lizardman** and **Slime** ancestry. Lizardman vitality and Slime spirit form a single stable lineage.

![Race icon](../assets/race/convergence/lizardman_slime.png)

| Race data | Value |
| --- | --- |
| Ancestries | Lizardman + Slime |
| Alignment | Chaos |
| Aura gain weight | 3.105 |
| Magicule gain weight | 2.895 |
| Growth at a baseline of 3, including +10% | 10.2465 aura / 9.5535 magicules |

## Obtaining

Finish both ancestral evolution paths, become a True Hero or True Demon Lord, and meet the fixed EP gate shown in the **Convergent Awakening** tab (at least 10M EP). Awakening grants a one-time +25% to both base energy pools and retains learned skills and the +10% EP gain bonus.

## Racial ability

**Concordance Pulse — no damage.** Heal 50% maximum HP and SHP, without a fixed amount cap, and push nearby enemies. Cost: **1,500 aura**. Cooldown: **30 seconds**. Healing stops at your current maximums.

Traits combine both final ancestries. [Awakening details and shared traits](Convergent-Awakening.md).
