# Skills

[All wikis](../README.md) · [TensuraAdditionalAdditions](TensuraAdditionalAdditions.md)

[Chained](Additions-Chained.md) is granted by Fettered Human and automatically evolves into [Unbound](Additions-Unbound.md) when its requirements are met. [Fusion](Additions-Fusion.md) temporarily combines bodies and skills with subordinates or consenting players. [Prospector](Additions-Prospector.md) grants mining bonuses, ore vision and refining. [Parallel World Jumper](Additions-Parallel-World-Jumper.md) joins private single-player reincarnation rolls.

[Battlewills](Additions-Battlewills.md) include Schema, Air Walk and Instant Transmission. [Aura recovery](Additions-Aura-Regeneration.md) is granted by the lineage’s later evolutions.

Use Tensura’s normal Ability Selection menu. Ultimate synthesis combines fully mastered component skills after completed true awakening and a personal achievement. Each recipe has a permanent magicule cost; awakening bonuses apply before payment.

[Ability directory](Additions-Abilities.md).

[Exponentiation](Additions-Exponentiation.md) raises supported beneficial values to ^1.2 while learned and equipped in your current skill preset. Movement is excluded.

[Loan Shark](Additions-Loan-Shark.md) lends skill copies, earns EP while they are used, and recalls or claims them through its report ledger.

[Split Mind](Additions-Split-Mind.md) adds +9 learning/mastery gain, Thought Acceleration, Chant Annulment and automatic casting of one assigned learned magic.

[Marauder's Map](Additions-Marauders-Map.md) maps visited and unvisited terrain, tracks all online players, locates structures and saves private pins.

[Critical Merchant](Additions-Critical-Merchant.md) compounds critical damage with chained coin flips and prepares ten guaranteed critical hits.

## Ultimate synthesis

[Hephaestus, Lord of the Forge](Additions-Hephaestus.md) combines fully mastered Prospector and Godly Craftsman after awakening and a personal forging achievement. No EP requirement. It adds Divine Forge, Living Arsenal and Magnum Opus.

[Metis, Lord of Wisdom](Additions-Metis.md) combines fully mastered Split Mind and Great Sage after completed true awakening and learning three magics. It adds a three-thread magical matrix (four at mastery), independent auto-casting and automatic magic-circle analysis. No EP requirement.

[Tyche, Lord of Fortune](Additions-Tyche.md) combines Critical Merchant and Tuner: critical odds, a timed low-HP/SHP buff and damage-type-based full revival.
