# Gravehide Colossus

> **Discontinued archive:** Tensura Myths ended at 0.36.1. No further updates are planned.

[All wikis](../README.md) · [Tensura Myths](Tensura-Myths.md)

**Gravehide Colossus** is the unique Convergent race formed from **Orc** and **Wight** ancestry. Orc vitality and Wight spirit form a single stable lineage.

![Race icon](../assets/race/convergence/orc_wight.png)

| Race data | Value |
| --- | --- |
| Ancestries | Orc + Wight |
| Alignment | Chaos |
| Aura gain weight | 3.075 |
| Magicule gain weight | 2.925 |
| Growth at a baseline of 3, including +10% | 10.1475 aura / 9.6525 magicules |

## Obtaining

Finish both ancestral evolution paths, become a True Hero or True Demon Lord, and meet the fixed EP gate shown in the **Convergent Awakening** tab (at least 10M EP). Awakening grants a one-time +25% to both base energy pools and retains learned skills and the +10% EP gain bonus.

## Racial ability

**Concordance Pulse — no damage.** Heal 50% maximum HP and SHP, without a fixed amount cap, and push nearby enemies. Cost: **1,500 aura**. Cooldown: **30 seconds**. Healing stops at your current maximums.

Traits combine both final ancestries. [Awakening details and shared traits](Convergent-Awakening.md).
