# Tempest Juggernaut

[All wikis](../README.md) · [Tensura Myths](Tensura-Myths.md)

**Tempest Juggernaut** is the unique Convergent race formed from **Harpy** and **Orc** ancestry. Harpy vitality and Orc spirit form a single stable lineage.

![Race icon](../assets/race/convergence/harpy_orc.png)

| Race data | Value |
| --- | --- |
| Ancestries | Harpy + Orc |
| Alignment | Chaos |
| Aura gain weight | 3.825 |
| Magicule gain weight | 2.175 |
| Growth at a baseline of 3, including +10% | 12.6225 aura / 7.1775 magicules |

## Obtaining

Finish both ancestral evolution paths, become a True Hero or True Demon Lord, and meet the fixed EP gate shown in the **Convergent Awakening** tab (at least 10M EP). Awakening grants a one-time +25% to both base energy pools and retains learned skills and the +10% EP gain bonus.

## Racial ability

**Concordance Pulse — no damage.** Heal 50% maximum HP and SHP, without a fixed amount cap, and push nearby enemies. Cost: **1,500 aura**. Cooldown: **30 seconds**. Healing stops at your current maximums.

Traits combine both final ancestries. [Awakening details and shared traits](Convergent-Awakening.md).
