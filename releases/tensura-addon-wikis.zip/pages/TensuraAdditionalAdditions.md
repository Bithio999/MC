# TensuraAdditionalAdditions

[All wikis](../README.md) · [TensuraAdditionalAdditions](TensuraAdditionalAdditions.md)

A standalone addon for **Tensura: Reincarnated**, focused on Heavenly Restriction, Battlewills and world travel. Current release: **1.27.0** · Minecraft **1.21.1** · NeoForge.

| Explore | Pages |
| --- | --- |
| Start | [Install](Additions-Getting-Started.md) · [In-game guide](Additions-In-Game-Guide.md) |
| Race | [Heavenly Restriction](Additions-Fettered-Human.md) |
| Skills | [Critical Merchant](Additions-Critical-Merchant.md), [Hephaestus](Additions-Hephaestus.md) · [Metis](Additions-Metis.md) · [Tyche](Additions-Tyche.md) · [Chained](Additions-Chained.md) · [Unbound](Additions-Unbound.md) · [Split Mind](Additions-Split-Mind.md) · [Loan Shark](Additions-Loan-Shark.md) · [Fusion](Additions-Fusion.md) · [Prospector](Additions-Prospector.md) · [Exponentiation](Additions-Exponentiation.md) · [Aura recovery](Additions-Aura-Regeneration.md) · [Marauder’s Map](Additions-Marauders-Map.md)|
| Battlewills | [Schema](Additions-Schema.md) · [Air Walk](Additions-Air-Walk.md) · [Instant Transmission](Additions-Instant-Transmission.md) |
| Dimensions | [The High Realm](Additions-The-High-Realm.md) |
| World travel | [Parallel World Jumper](Additions-Parallel-World-Jumper.md) |
| Gear | [Vesper](Additions-Vesper.md) · [Inverted Spear of Heaven](Additions-Inverted-Spear-of-Heaven.md) · [Nullification](Additions-Nullification.md) |

[Download Additions 1.27.0](../../releases/TensuraAdditionalAdditions-1.27.0.jar). Tensura Myths is not required. Do not install both addons together. Myths’ Godly skills, bosses, hunters and dual-race systems are not part of this addon.

## Rare boss

[Kael Veyr, the Starless Wayfarer](Additions-Kael-Veyr.md) is a rare 15M-EP otherworlder encounter in The High Realm.

[Chromatic Orb](Additions-Chromatic-Orb.md): a one-time engraving upgrade crafted from High Realm shards and Kael’s Starless Core.

## Unique Skill mentorship

Find **Elias, the Archivist** in the rare [Archive of Accord](Additions-Archive-of-Accord.md). Each player may buy one permanent, unmastered Unique Skill for **1,000,000 permanent EP and one Chromatic Orb** by default.

[Laplace, Lord of Equations](Additions-Laplace.md) combines Exponentiation and Mathematician. Universal Formula inherits their benefits; Equation Editor changes verified native formulas with a live cost preview.
