# Bloodmoon Lycan

[All wikis](../README.md) · [Tensura Myths](Tensura-Myths.md)

**Bloodmoon Lycan** is the unique Convergent race formed from **Beastfolk** and **Vampire** ancestry. Beastfolk vitality and Vampire spirit form a single stable lineage.

![Race icon](../assets/race/convergence/beastfolk_vampire.png)

| Race data | Value |
| --- | --- |
| Ancestries | Beastfolk + Vampire |
| Alignment | Chaos |
| Aura gain weight | 2.795 |
| Magicule gain weight | 3.205 |
| Growth at a baseline of 3, including +10% | 9.2235 aura / 10.5765 magicules |

## Obtaining

Finish both ancestral evolution paths, become a True Hero or True Demon Lord, and meet the fixed EP gate shown in the **Convergent Awakening** tab (at least 10M EP). Awakening grants a one-time +25% to both base energy pools and retains learned skills and the +10% EP gain bonus.

## Racial ability

**Concordance Pulse — no damage.** Heal 50% maximum HP and SHP, without a fixed amount cap, and push nearby enemies. Cost: **1,500 aura**. Cooldown: **30 seconds**. Healing stops at your current maximums.

Traits combine both final ancestries. [Awakening details and shared traits](Convergent-Awakening.md).
