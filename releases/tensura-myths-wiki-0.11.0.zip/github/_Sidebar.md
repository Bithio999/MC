# Tensura Myths

[Home](https://github.com/Bithio999/MC/wiki)

### Start here

- [Getting started](https://github.com/Bithio999/MC/wiki/Getting-Started)

### Skills

- [Skill overview](https://github.com/Bithio999/MC/wiki/Skills)
- [Unique Skills](https://github.com/Bithio999/MC/wiki/Unique-Skills)
- [Ultimate Skills](https://github.com/Bithio999/MC/wiki/Ultimate-Skills)
- [Godly Skills](https://github.com/Bithio999/MC/wiki/Godly)
- [Extra Skills](https://github.com/Bithio999/MC/wiki/Aura-Regeneration)
- [Ability index](https://github.com/Bithio999/MC/wiki/Abilities)

### Races

- [Race directory](https://github.com/Bithio999/MC/wiki/Races)
- [Hunter evolution](https://github.com/Bithio999/MC/wiki/Evolution)
- [Secondary races](https://github.com/Bithio999/MC/wiki/Duo-Races)
- [Convergent Awakening](https://github.com/Bithio999/MC/wiki/Convergent-Awakening)

### Otherworlders

- [Character directory](https://github.com/Bithio999/MC/wiki/Otherworlders)
- [Alma](https://github.com/Bithio999/MC/wiki/Alma)
- [Gemma](https://github.com/Bithio999/MC/wiki/Gemma)

### Reference

- [Damage types](https://github.com/Bithio999/MC/wiki/Damage-Types)
- [Combat mechanics](https://github.com/Bithio999/MC/wiki/Mechanics)
- [Commands](https://github.com/Bithio999/MC/wiki/Commands)

