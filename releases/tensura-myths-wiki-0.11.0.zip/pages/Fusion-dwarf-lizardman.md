# Runebound Fafnir

[Main Page](../README.md) · [Races](Races.md) · [Ability index](Abilities.md) · [Damage types](Damage-Types.md)

**Runebound Fafnir** is the unique Convergent race formed from **Lizardman** and **Dwarf** ancestry. Lizardman vitality and Dwarf spirit form a single stable lineage.

![Runebound Fafnir](../../src/main/resources/assets/wildhunt/textures/race/convergence/dwarf_lizardman.png)

| Race data | Runebound Fafnir |
| --- | --- |
| **Information** | |
| Classification | Convergent / final evolution |
| Ancestries | Lizardman + Dwarf |
| Alignment | Chaos |
| Aura gain weight | 4.1 |
| Magicule gain weight | 1.9 |
| Growth at a baseline of 3, including +10% | 13.53 aura / 6.27 magicules |
| Racial action | Concordance Pulse |
| Registry ID | `wildhunt:convergence/dwarf_lizardman` |
| **Evolution** | |
| Previous | Both selected races at their final evolution |
| Evolution | — |
| **Obtaining** | |
| Awakening | True Hero or True Demon Lord |
| Base EP | [Lineage-dependent](Convergent-Awakening.md#ep-requirement); 10,000,000 minimum by default |
| Method | Convergent Awakening |

## Obtaining

Develop Lizardman and Dwarf as your two recorded ancestries, finish **both** evolution paths, and satisfy the [Convergent Awakening requirements](Convergent-Awakening.md#obtaining). Awakening grants a one-time configurable **25% increase to both base energy pools**, then uses this race's own future EP allocation. It cannot be repeated to farm the bonus.
## Traits

The fused body draws its intrinsic skill list and native race tags from the native final stages of both ancestral families. Previously learned intrinsic skills remain in native storage. Saved racial reactions and ticks from the actual two former stages continue to run. Body size does not combine the two ancestors' scales.

Shared additive attributes use **65% of each family's native final-stage bonus**, plus **80 HP**, **1,500 SHP**, and an additional pair-dependent attack bonus. The total HP race bonus is capped at **1,000**. These replace the old primary and secondary attribute contributions. Configured native race values affect the result.

## Racial Ability

[Active - Racial Action] — **Concordance Pulse**

**Damage type:** None — healing and knockback. **Damage ID:** —. The pulse does not call an attack damage source; its visual is not elemental damage.

Heal **10% of maximum HP**, capped at **80 HP**, and push eligible enemies within seven blocks away. The pulse costs **1,500 aura** and has a **30-second cooldown**. Its visual combines the two ancestral colors. Native sleep and movement-control restrictions prevent activation.

This action is shared by Convergent races; their ancestry-derived traits, icons and EP profiles distinguish each pair.

## EP growth

Future native kill awards use **4.1 aura weight / 1.9 magicule weight**. The inherited **10% EP gain bonus** multiplies both weights by 1.1 without changing their proportions. Native gain attributes, penalties and caps still apply. Reversing the primary and secondary order produces this same race and growth profile.

---

**Categories:** Tensura Myths · Races · Convergent races
