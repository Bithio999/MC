# Skills

[Main Page](../README.md) · [Skills](Skills.md) · [Evolution](Evolution.md) · [Mechanics](Mechanics.md) · [Commands](Commands.md)

Four rollable Uniques evolve into four Ultimates. Every line has **two active modes plus one toggleable passive**. Each Ultimate adds a **third active signature**.

| Unique | Ultimate | Active arts | Toggleable passive |
| --- | --- | --- | --- |
| [Storm Crown](Storm-Crown.md) | [Raijin](Raijin.md) | Ricochet Railbolt; Thunder Step | Storm Mantle |
| [Scarlet Deluge](Scarlet-Deluge.md) | [Varuna](Varuna.md) | Travelling wave; aimed whirlpool | Water Veil |
| [Black Flame](Black-Flame.md) | [Agni](Agni.md) | Rendered Oil Lash; pool ignition | Furnace Mantle |
| [Frostbound Colossus](Frostbound-Colossus.md) | [Ymir](Ymir.md) | Avalanche Crash; Glacial Prison | Colossus Carapace |

## Obtaining skills

Uniques join Tensura’s configured reincarnation primary pool. Rolls remain random. There are no skill trials or skills awarded for boss kills. Ultimates require Sovereign Hunter, two million base EP and mastery of the matching Unique.

## Using skills

Equip and cycle active modes using Tensura’s normal ability interface. Enable the passive with the native skill toggle in **Ability Selection**; it is separate from the active modes. It requires ongoing aura. `/wildhunt status` shows its on/off state and upkeep.

## Power

Mastery improves damage by up to 50%; Ultimates use a 3× base multiplier. Damage does not scale with EP. Read [Combat mechanics](Mechanics.md) for damage types, barriers, and aura costs.

---

**Categories:** Tensura: Wild Hunt
