# Heavenbreaker

[Main Page](https://github.com/Bithio999/MC/wiki/Home) · [Race directory](https://github.com/Bithio999/MC/wiki/Races) · [Chained](https://github.com/Bithio999/MC/wiki/Chained)

**Heavenbreaker** is evolution 4 of four of the **Heavenly Restriction** lineage. A human-looking martial body exchanges magical growth for exceptional physical and aura potential through its intrinsic Unique Skill, **Chained**.

![Heavenbreaker](https://github.com/Bithio999/MC/blob/main/wiki/assets/race/heavenbreaker.png?raw=true)

| Race data | Heavenbreaker |
| --- | --- |
| **Information** | |
| Registry ID | `wildhunt:heavenbreaker` |
| Ancestry | Human |
| Stage | 4 / 4 evolutions |
| Intrinsic Unique | [Chained](https://github.com/Bithio999/MC/wiki/Chained) |
| HP racial bonus | +1,000 |
| SHP racial bonus | +6,600 |
| Attack bonus | +16 before Chained’s toggle multiplier |
| Movement bonus | +30% of base movement |
| Knockback resistance bonus | +0.6 |
| Previous evolution | [Heavenly Restricted](https://github.com/Bithio999/MC/wiki/Heavenly-Restricted) |
| Next evolution | Final stage |

## Traits

The race preserves the player’s appearance and equipment. Stage bonuses replace the preceding stage’s bonuses. Its ordinary Human EP split remains **2/3 aura and 1/3 magicules**, before Chained’s rules: aura capacity is multiplied by 100 and future maximum-magicule gains are blocked. The blocked share is not reassigned. A newly reincarnated Fettered Human has 20,000 base aura and 500 base magicules; Chained makes its aura capacity 2,000,000.

[Chained](https://github.com/Bithio999/MC/wiki/Chained) governs true resource/learning restrictions, the martial toggle, mastered resistance degradation, in-slot dodge and Severance Rush. The same skill and mastery persist through the lineage.

## Intrinsic skill

The intrinsic Unique [Chained](https://github.com/Bithio999/MC/wiki/Chained) supplies the lineage’s true restriction and martial abilities. Its active [Severance Rush](https://github.com/Bithio999/MC/wiki/Chained#severance-rush) is an instant teleport that deals native **Aura slash / Battlewill** damage (`tensura:aura_slash`). The race’s attribute bonuses are passive traits with no direct damage.

## Evolution

Requires **8,000,000 fixed base EP**, **4 mastered Battlewills, and **mastered Chained**. All requirements must be met in Tensura’s native evolution menu.

Base EP uses the native unmultiplied capacity values; the 100× aura-capacity modifier does not satisfy a base-EP gate by itself. The milestones are constants, independent of the player’s EP when the lineage is selected.

| Stage | Fixed base EP | Mastered Battlewills | Chained mastery |
| --- | ---: | ---: | ---: |
| [Fettered Human](https://github.com/Bithio999/MC/wiki/Fettered-Human) | Starting selection | — | — |
| [Tempered Vessel](https://github.com/Bithio999/MC/wiki/Tempered-Vessel) | 100,000 | 1 | 20% |
| [Unshackled](https://github.com/Bithio999/MC/wiki/Unshackled) | 500,000 | 2 | 40% |
| [Heavenly Restricted](https://github.com/Bithio999/MC/wiki/Heavenly-Restricted) | 2,000,000 | 3 | 60% |
| [Heavenbreaker](https://github.com/Bithio999/MC/wiki/Heavenbreaker) | 8,000,000 | 4 | 100% |

As the final Human-family branch, Heavenbreaker can meet the primary-lineage completion condition for [secondary races](https://github.com/Bithio999/MC/wiki/Duo-Races). Chained’s ownership restrictions still apply to subsequent skill acquisitions.

---

**Categories:** Tensura Myths · Races
