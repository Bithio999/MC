# Runic Exemplar

[Main Page](https://github.com/Bithio999/MC/wiki/Home) · [Duo Races](https://github.com/Bithio999/MC/wiki/Duo-Races) · [Convergent Awakening](https://github.com/Bithio999/MC/wiki/Convergent-Awakening)

**Runic Exemplar** is the unique Convergent race formed from **Human** and **Dwarf** ancestry. Human vitality and Dwarf spirit form a single stable lineage.

![Runic Exemplar](https://github.com/Bithio999/MC/blob/main/src/main/resources/assets/wildhunt/textures/race/convergence/dwarf_human.png?raw=true)

| Race data | Runic Exemplar |
| --- | --- |
| **Information** | |
| Classification | Convergent / final evolution |
| Ancestries | Human + Dwarf |
| Alignment | Chaos |
| Aura gain weight | 4.19 |
| Magicule gain weight | 1.81 |
| Growth at a baseline of 3 | 12.57 aura / 5.43 magicules |
| Racial action | Concordance Pulse |
| Registry ID | `wildhunt:convergence/dwarf_human` |
| **Evolution** | |
| Previous | Both selected races at their final evolution |
| Evolution | — |
| **Obtaining** | |
| Awakening | True Hero or True Demon Lord |
| Base EP | 10,000,000 by default |
| Method | Convergent Awakening |

## Traits

The fused body draws its intrinsic skill list and native race tags from the native final stages of both ancestral families. Previously learned intrinsic skills remain in native storage. Saved racial reactions and ticks from the actual two former stages continue to run. Body size does not combine the two ancestors' scales.

Shared additive attributes use **65% of each family's native final-stage bonus**, plus **80 HP**, **1,500 SHP**, and an additional pair-dependent attack bonus. The total HP race bonus is capped at **1,000**. These replace the old primary and secondary attribute contributions. Configured native race values affect the result.

## Racial Ability

[Active - Racial Action] — **Concordance Pulse**

Heal **10% of maximum HP**, capped at **80 HP**, and push eligible enemies within seven blocks away. The pulse costs **1,500 aura** and has a **30-second cooldown**. Its visual combines the two ancestral colors. Native sleep and movement-control restrictions prevent activation.

This action is shared by Convergent races; their ancestry-derived traits, icons and EP profiles distinguish each pair.

## EP growth

Future native kill awards use **4.19 aura weight / 1.81 magicule weight**. This profile replaces the earlier primary-plus-half-secondary formula. Native gain attributes, penalties and caps still apply. Reversing the primary and secondary order produces this same race and growth profile.

## Obtaining

Develop Human and Dwarf as your two recorded ancestries, finish **both** evolution paths, and satisfy the [Convergent Awakening requirements](https://github.com/Bithio999/MC/wiki/Convergent-Awakening#obtaining). Awakening grants a one-time configurable **25% increase to both base energy pools**, then uses this race's own future EP allocation. It cannot be repeated to farm the bonus.
